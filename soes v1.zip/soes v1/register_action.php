<?php
include('admin/soes.php');
$object = new soes();
if($_POST['action'] == 'register')
{
		$error = '';

		$success = '';
		
		// if($_POST['action'] == 'check_email')
		// {
			// $object->query = "
			// SELECT * FROM student_soes 
			// WHERE student_email_id = '".trim($_POST["email"])."'
			// ";

			// $object->execute($data);

			// if($object->row_count() > 0)
			// {
				// $output = array(
					// 'success'		=>	true
				// );
				// echo json_encode($output);
			// }
		// }

		$data = array(
			':student_email_id'	=>	$_POST["user_email_address"]
		);

		$object->query = "
		SELECT * FROM student_soes 
		WHERE student_email_id = :student_email_id 
		";

		$object->execute($data);

		if($object->row_count() > 0)
		{
			$error = '<div class="alert alert-danger">Student Data Already Exists</div>';
		}
		else
		{
			$student_image = '';

			if($_FILES['user_image']['name'] != '')
			{
				$student_image = upload_image();
			}
			
			$student_email_verification_code = md5(uniqid());

			$receiver_email = $_POST['user_email_address'];
			
			$data = array(
				':student_name'			=>	$_POST["user_name"],
				':student_address'		=>	$_POST["user_address"],
				':student_email_id'		=>	$_POST["user_email_address"],
				':student_password'		=>	$_POST["user_password"],
				':student_gender'		=>	$_POST["user_gender"],
				':student_dob'			=>	'1997-05-26',
				':student_image'		=>	$student_image,
				':student_mobile_no'		=>	$_POST['user_mobile_no'],
				':student_status'		=>	'Enable',
				':student_email_verified'		=>	'No',
				':student_added_by'		=>	'Me',
				':student_added_on'		=>	$object->now,
				':student_email_verification_code'		=>	$student_email_verification_code
			);

			$object->query = "
			INSERT INTO student_soes 
			(student_name, student_address, student_email_id, student_password, student_gender, student_dob, student_image, student_status, student_added_by, student_added_on, student_email_verified, student_mobile_no, student_email_verification_code) 
			VALUES (:student_name, :student_address, :student_email_id, :student_password, :student_gender, :student_dob, :student_image, :student_status, :student_added_by, :student_added_on, :student_email_verified, :student_mobile_no, :student_email_verification_code)
			";

			$object->execute($data);		
			
			//require_once('class/class.phpmailer.php');
			$subject= 'Asad Quiz Registration Verification';
			$body = '
			<p>Thank you for registering.</p>
			<p>This is a verification eMail, please click the link to verify your eMail address by clicking this  <a href="'.$object->base_url.'verify_email.php?type=student&code='.$student_email_verification_code.'" target="_blank"><b>link</b></a>..</p>
			<p>In case if you have any difficulty please eMail us.</p>
			<p>Thank you,</p>
			<p>Asad Online Quiz System</p>
			';
			$body = wordwrap($body,50);
			$sender = " avvasthani@gmail.com";
			$headers = "MIME-Version:1.0"."/r/n";
			$headers .= "Content-type:text/html;charset=UTF-8" ."/r/n";
			$headers .= "From:<avvasthani@gmail.com>" ."/r/n";
			$headers .= "Cc:zaki@gmail.com" ."/r/n";

			@mail($receiver_email,$subject,$body,$headers,'-f'.$sender);

			//$object->send_email($receiver_email, $subject, $body);

			$success = '<div class="alert alert-success">Student Data Successfully Added</div>';
		}
					
		$output = array(
			'error'		=>	$error,
			'success'	=>	$success
		);

		echo json_encode($output);

	}
function upload_image()
{
	if(isset($_FILES['user_image']))
	{
		$extension = explode('.', $_FILES['user_image']['name']);
		$new_name = rand() . '.' . $extension[1];
		$destination = 'images/' . $new_name;
		move_uploaded_file($_FILES['user_image']['tmp_name'], $destination);
		$destination = "../".$destination;
		return $destination;
	}
}

?>