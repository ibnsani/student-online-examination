-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 23, 2021 at 01:44 AM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `soes`
--

-- --------------------------------------------------------

--
-- Table structure for table `class_soes`
--

DROP TABLE IF EXISTS `class_soes`;
CREATE TABLE IF NOT EXISTS `class_soes` (
  `class_id` int(11) NOT NULL AUTO_INCREMENT,
  `class_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `class_code` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `class_status` enum('Enable','Disable') COLLATE utf8_unicode_ci NOT NULL,
  `class_created_on` datetime NOT NULL,
  PRIMARY KEY (`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `exam_soes`
--

DROP TABLE IF EXISTS `exam_soes`;
CREATE TABLE IF NOT EXISTS `exam_soes` (
  `exam_id` int(11) NOT NULL AUTO_INCREMENT,
  `exam_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `exam_class_id` int(11) NOT NULL,
  `exam_duration` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `exam_status` enum('Pending','Created','Started','Completed') COLLATE utf8_unicode_ci NOT NULL,
  `exam_created_on` datetime NOT NULL,
  `exam_code` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `exam_result_datetime` datetime DEFAULT NULL,
  PRIMARY KEY (`exam_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `exam_subject_question_answer`
--

DROP TABLE IF EXISTS `exam_subject_question_answer`;
CREATE TABLE IF NOT EXISTS `exam_subject_question_answer` (
  `answer_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `exam_subject_question_id` int(11) NOT NULL,
  `student_answer_option` enum('0','1','2','3','4') COLLATE utf8_unicode_ci NOT NULL,
  `marks` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`answer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `exam_subject_question_soes`
--

DROP TABLE IF EXISTS `exam_subject_question_soes`;
CREATE TABLE IF NOT EXISTS `exam_subject_question_soes` (
  `exam_subject_question_id` int(11) NOT NULL AUTO_INCREMENT,
  `exam_id` int(11) NOT NULL,
  `exam_subject_id` int(11) NOT NULL,
  `exam_subject_question_title` text COLLATE utf8_unicode_ci NOT NULL,
  `exam_subject_question_answer` enum('1','2','3','4') COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`exam_subject_question_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `question_option_soes`
--

DROP TABLE IF EXISTS `question_option_soes`;
CREATE TABLE IF NOT EXISTS `question_option_soes` (
  `question_option_id` int(11) NOT NULL AUTO_INCREMENT,
  `exam_subject_question_id` int(11) NOT NULL,
  `question_option_number` int(1) NOT NULL,
  `question_option_title` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`question_option_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `student_soes`
--

DROP TABLE IF EXISTS `student_soes`;
CREATE TABLE IF NOT EXISTS `student_soes` (
  `student_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `student_address` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `student_email_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `student_password` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `student_gender` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `student_dob` date DEFAULT NULL,
  `student_image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `student_status` enum('Enable','Disable') COLLATE utf8_unicode_ci NOT NULL,
  `student_email_verification_code` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `student_email_verified` enum('No','Yes') COLLATE utf8_unicode_ci NOT NULL,
  `student_added_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `student_added_on` datetime DEFAULT NULL,
  `student_mobile_no` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `student_to_class_soes`
--

DROP TABLE IF EXISTS `student_to_class_soes`;
CREATE TABLE IF NOT EXISTS `student_to_class_soes` (
  `student_to_class_id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `student_roll_no` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `added_on` datetime NOT NULL,
  PRIMARY KEY (`student_to_class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subject_soes`
--

DROP TABLE IF EXISTS `subject_soes`;
CREATE TABLE IF NOT EXISTS `subject_soes` (
  `subject_id` int(11) NOT NULL AUTO_INCREMENT,
  `subject_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `subject_status` enum('Enable','Disable') COLLATE utf8_unicode_ci NOT NULL,
  `subject_created_on` datetime NOT NULL,
  PRIMARY KEY (`subject_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subject_to_class_soes`
--

DROP TABLE IF EXISTS `subject_to_class_soes`;
CREATE TABLE IF NOT EXISTS `subject_to_class_soes` (
  `subject_to_class_id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `added_on` datetime NOT NULL,
  PRIMARY KEY (`subject_to_class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subject_wise_exam_detail`
--

DROP TABLE IF EXISTS `subject_wise_exam_detail`;
CREATE TABLE IF NOT EXISTS `subject_wise_exam_detail` (
  `exam_subject_id` int(11) NOT NULL AUTO_INCREMENT,
  `exam_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `subject_total_question` int(5) NOT NULL,
  `marks_per_right_answer` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `marks_per_wrong_answer` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `subject_exam_datetime` datetime NOT NULL,
  `subject_exam_status` enum('Pending','Started','Completed') COLLATE utf8_unicode_ci DEFAULT NULL,
  `subject_exam_code` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`exam_subject_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_soes`
--

DROP TABLE IF EXISTS `user_soes`;
CREATE TABLE IF NOT EXISTS `user_soes` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `user_contact_no` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `user_email` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `user_password` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `user_profile` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `user_type` enum('Master','User') COLLATE utf8_unicode_ci NOT NULL,
  `user_status` enum('Enable','Disable') COLLATE utf8_unicode_ci NOT NULL,
  `user_created_on` datetime NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user_soes`
--

INSERT INTO `user_soes` (`user_id`, `user_name`, `user_contact_no`, `user_email`, `user_password`, `user_profile`, `user_type`, `user_status`, `user_created_on`) VALUES
(1, 'asad', '0809644743', 'asad@admin.com', '12345', '../images/262547648.jpg', 'Master', 'Enable', '2021-06-20 19:28:51'),
(2, 'sadiq', '08096044743', 'sadiq@gmail.com', '123456', '../images/1743247339.jpg', 'User', 'Enable', '2021-06-21 00:09:09');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
